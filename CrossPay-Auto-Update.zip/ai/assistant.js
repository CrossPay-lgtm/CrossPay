// Mock AI assistant module.
// Replace with OpenAI calls when you have a key.
// Functions: analyzeTx(tx), faq(query)
module.exports = {
  analyzeTx(tx){
    // simple anomaly detection (amount > threshold)
    const alerts = [];
    if(tx.amount > 10000) alerts.push('Large transaction flagged');
    return { alerts };
  },
  faq(q){
    const lower = q.toLowerCase();
    if(lower.includes('deposit')) return 'To deposit, go to Wallet > Deposit and follow the instructions.';
    return 'Sorry, I do not understand. Contact support.';
  }
};
