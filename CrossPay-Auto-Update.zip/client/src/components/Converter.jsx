import React, { useState } from 'react';

export default function Converter(){
  const [from, setFrom] = useState('USD');
  const [to, setTo] = useState('GHS');
  const [amount, setAmount] = useState(1);
  const [result, setResult] = useState(null);

  async function convert(){
    const res = await fetch('/convert', {
      method:'POST', headers:{ 'Content-Type':'application/json' },
      body: JSON.stringify({ from, to, amount, markup: 0.02 })
    });
    const j = await res.json();
    setResult(j);
  }

  return (
    <div>
      <div style={{display:'flex', gap:8, marginBottom:8}}>
        <input value={amount} onChange={e=>setAmount(e.target.value)} />
        <input value={from} onChange={e=>setFrom(e.target.value)} style={{width:60}}/>
        <input value={to} onChange={e=>setTo(e.target.value)} style={{width:60}}/>
        <button onClick={convert}>Convert</button>
      </div>
      {result && <div>
        <div>Rate: {result.rate}</div>
        <div>Final: {result.finalRate}</div>
        <div>Converted: {result.converted}</div>
      </div>}
    </div>
  );
}
