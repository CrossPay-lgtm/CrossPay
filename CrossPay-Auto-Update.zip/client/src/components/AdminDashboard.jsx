import React, { useEffect, useState } from 'react';

export default function AdminDashboard(){
  const [profits, setProfits] = useState({ total:0, entries:[] });
  const [db, setDb] = useState(null);

  useEffect(()=> { load(); }, []);
  async function load(){
    const p = await fetch('/profit').then(r=>r.json()).catch(()=>({ total:0, entries:[] }));
    setProfits(p);
    const full = await fetch('/_db').then(r=>r.json()).catch(()=>null);
    setDb(full);
  }

  async function resetData(){
    if(!confirm('Reset demo data?')) return;
    await fetch('/reset', { method:'POST' });
    load();
    alert('Reset done');
  }

  return (
    <div className="card">
      <h2>Admin</h2>
      <p><strong>Total Profit:</strong> {profits.total}</p>
      <button onClick={load}>Refresh</button>
      <button onClick={resetData}>Reset Demo Data</button>
      <h3>Recent Profit Entries</h3>
      <ul>
        {profits.entries.map(e => <li key={e.id || e.time}>{e.type} {e.amount} fee:{e.fee}</li>)}
      </ul>
      <h3>Raw DB (dev)</h3>
      <pre style={{maxHeight:200, overflow:'auto'}}>{JSON.stringify(db, null, 2)}</pre>
    </div>
  );
}
