import React, { useEffect, useState } from 'react';
import Converter from './Converter';

export default function UserDashboard(){
  const userId = 'user_1';
  const [balance, setBalance] = useState(0);
  const [txs, setTxs] = useState([]);

  useEffect(()=> {
    refresh();
    function onDeposit(){ doTx('deposit'); }
    function onSend(){ doTx('send'); }
    function onWithdraw(){ doTx('withdraw'); }
    window.addEventListener('crosspay.deposit', onDeposit);
    window.addEventListener('crosspay.send', onSend);
    window.addEventListener('crosspay.withdraw', onWithdraw);
    return ()=> {
      window.removeEventListener('crosspay.deposit', onDeposit);
      window.removeEventListener('crosspay.send', onSend);
      window.removeEventListener('crosspay.withdraw', onWithdraw);
    };
  }, []);

  async function refresh(){
    const p = await fetch('/profit').then(r=>r.json()).catch(()=>({ total:0, entries:[] }));
    setTxs(p.entries || []);
    const full = await fetch('/_db').then(r=>r.json()).catch(()=>null);
    if(full && full.users){
      const u = full.users.find(x=>x.id==='user_1');
      if(u) setBalance(u.balance);
    }
  }

  async function doTx(type){
    const amt = Number(prompt(`Enter amount for ${type}`, '10'));
    if(!amt || amt <= 0) return;
    const res = await fetch('/transaction', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ type, userId, amount: amt })
    });
    const j = await res.json();
    if(j.ok){
      setBalance(j.balance);
      setTxs(prev => [j.tx, ...prev]);
      alert(`${type} done. New balance: ${j.balance}`);
    } else {
      alert('Error: '+JSON.stringify(j));
    }
  }

  return (
    <div className="card">
      <h2>Wallet</h2>
      <p><strong>Balance:</strong> {balance}</p>
      <Converter />
      <h3>Recent</h3>
      <ul>
        {txs.map(t => <li key={t.id}>{t.type} {t.amount} fee:{t.fee}</li>)}
      </ul>
    </div>
  );
}
