import React, { useState } from 'react';
import UserDashboard from './components/UserDashboard';
import AdminDashboard from './components/AdminDashboard';

export default function App(){
  const [view, setView] = useState('user');
  return (
    <div className="app">
      <header className="topbar">
        <h1>CrossPay</h1>
        <div>
          <button onClick={()=>setView('user')} className={view==='user'?'active':''}>User</button>
          <button onClick={()=>setView('admin')} className={view==='admin'?'active':''}>Admin</button>
        </div>
      </header>
      {view === 'user' ? <UserDashboard/> : <AdminDashboard/>}
      <nav className="fab">
        <button onClick={()=>window.dispatchEvent(new Event('crosspay.deposit'))}>Deposit</button>
        <button onClick={()=>window.dispatchEvent(new Event('crosspay.send'))}>Send</button>
        <button onClick={()=>window.dispatchEvent(new Event('crosspay.withdraw'))}>Withdraw</button>
      </nav>
    </div>
  );
}
